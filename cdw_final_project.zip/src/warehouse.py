import csv
from pathlib import Path
from collections import Counter, defaultdict

class ClinicalDataWarehouse:
    def __init__(self, data_dir: str | Path):
        self.data_dir = Path(data_dir)
        self.patients_path = self.data_dir / "patients.csv"
        self.encounters_path = self.data_dir / "encounters.csv"
        self.notes_path = self.data_dir / "notes.csv"
        self.procedures_path = self.data_dir / "procedures.csv"
        self.providers_path = self.data_dir / "providers.csv"
        self.departments_path = self.data_dir / "departments.csv"

        self.patients = self._read_csv(self.patients_path)
        self.encounters = self._read_csv(self.encounters_path)
        self.notes = self._read_csv(self.notes_path)
        self.procedures = self._read_csv(self.procedures_path)
        self.providers = self._read_csv(self.providers_path)
        self.departments = self._read_csv(self.departments_path)

    def _read_csv(self, path: Path) -> list[dict]:
        with path.open(newline="", encoding="utf-8") as f:
            return list(csv.DictReader(f))

    def _write_csv(self, path: Path, rows: list[dict], fieldnames: list[str]):
        with path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)

    def save_patients(self):
        fieldnames = ["patient_id", "age", "gender", "bmi", "a1c", "bp_sys", "bp_dia", "smoking"]
        self._write_csv(self.patients_path, self.patients, fieldnames)

    def retrieve_patient(self, patient_id: str) -> dict | None:
        matches = [p for p in self.patients if p["patient_id"] == patient_id]
        return matches[-1] if matches else None

    def add_patient(self, patient: dict) -> str:
        required = ["patient_id", "age", "gender", "bmi", "a1c", "bp_sys", "bp_dia", "smoking"]
        clean = {key: patient.get(key, "") for key in required}
        if not clean["patient_id"]:
            return "Patient ID is required."
        self.patients.append(clean)
        self.save_patients()
        return f"Patient {clean['patient_id']} added successfully."

    def remove_patient(self, patient_id: str) -> str:
        before = len(self.patients)
        self.patients = [p for p in self.patients if p["patient_id"] != patient_id]
        if len(self.patients) == before:
            return f"Patient {patient_id} not found."
        self.save_patients()
        return f"Patient {patient_id} removed from patients.csv."

    def count_visits_by_date(self, date: str) -> int:
        return sum(1 for e in self.encounters if e["encounter_date"] == date)

    def count_encounters_per_patient(self) -> list[tuple[str, int]]:
        counts = Counter(e["patient_id"] for e in self.encounters)
        return counts.most_common()

    def count_encounters_by_department(self) -> list[tuple[str, int]]:
        dept_names = {d["department_id"]: d["name"] for d in self.departments}
        counts = Counter(e["department_id"] for e in self.encounters)
        return [(dept_names.get(dept, dept), count) for dept, count in counts.most_common()]

    def view_note(self, patient_id: str, date: str) -> list[dict]:
        return [
            n for n in self.notes
            if n["patient_id"] == patient_id and n["note_date"] == date
        ]

    def monitor_provider_workload(self) -> list[tuple[str, int]]:
        provider_names = {p["provider_id"]: p["name"] for p in self.providers}
        counts = Counter(e["provider_id"] for e in self.encounters)
        return [(provider_names.get(provider, provider), count) for provider, count in counts.most_common()]

    def monitor_department_revenue(self) -> list[tuple[str, float]]:
        encounter_to_dept = {e["encounter_id"]: e["department_id"] for e in self.encounters}
        dept_names = {d["department_id"]: d["name"] for d in self.departments}
        revenue = defaultdict(float)

        for proc in self.procedures:
            dept_id = encounter_to_dept.get(proc["encounter_id"], "Unknown")
            revenue[dept_names.get(dept_id, dept_id)] += float(proc["cost"])

        return sorted(revenue.items(), key=lambda item: item[1], reverse=True)

    def key_statistics(self) -> str:
        total_patients = len(self.patients)
        total_encounters = len(self.encounters)
        total_notes = len(self.notes)
        total_procedures = len(self.procedures)
        avg_age = sum(float(p["age"]) for p in self.patients) / total_patients
        avg_bmi = sum(float(p["bmi"]) for p in self.patients) / total_patients

        return (
            f"Total patients: {total_patients}\n"
            f"Total encounters: {total_encounters}\n"
            f"Total notes: {total_notes}\n"
            f"Total procedures: {total_procedures}\n"
            f"Average age: {avg_age:.1f}\n"
            f"Average BMI: {avg_bmi:.1f}"
        )
